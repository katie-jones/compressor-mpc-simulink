folder = '/home/katie/school/MasterThesis/cpp/serial/output/';

for i=1:9
    f = fopen([folder,'ncoop_new_times',num2str(i),'.dat'],'r');
    A = fscanf(f,'%f');
    fclose(f);
    cpu_times(:,i) = A;
end