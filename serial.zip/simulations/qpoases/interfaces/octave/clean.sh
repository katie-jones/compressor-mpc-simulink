rm *.*~
rm *.o
rm qpOASES qpOASES_sequence qpOASES_sequenceSB qpOASES_sequenceVM
 