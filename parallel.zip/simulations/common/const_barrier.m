function [n,delta] = const_barrier()
%#eml
n = 1e2; % barrier constant
delta = 0.1; % offset at ur=0

end